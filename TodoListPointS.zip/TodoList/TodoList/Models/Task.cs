﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TodoList.Models
{
    public class Task
    {
        public int Id { get; set; }
        [Required(AllowEmptyStrings =false)]
        public string TaskName { get; set; }

        public bool Success { get; set; }
    }
}
